This file should contain an overview of your widget.

It is a markdown so can (and probably should) contain some screen shots of your widget.

It is the content of this file that appears on the Visual Studio Marketplace website hosting your widget ([click here for an example](https://marketplace.visualstudio.com/items?itemName=GregTrevellick.vsts-extensions-tweets-vsts)) should you choose to have your widget hosted there.

Unless your widget is exclusively for your personal or company internal usage you probably will upload your widget to the Visual Studio Marketplace website ([see here for instructions on how to do this](https://docs.microsoft.com/en-us/vsts/extend/publish/overview?view=vsts)) and hence Visual Studio Marketplace website will host your widget.